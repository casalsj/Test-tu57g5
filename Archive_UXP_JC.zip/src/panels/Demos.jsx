import React from "react";

import { ColorPicker } from "../components/ColorPicker.jsx";

export const Demos = () => {
    return (
        <>
            <ColorPicker />
        </>
    )
} 
